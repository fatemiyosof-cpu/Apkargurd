# AR Guard

یک کلاینت WireGuard برای اندروید (Kotlin + Jetpack Compose) که از موتور رسمی WireGuard
(`com.wireguard.android:tunnel`) استفاده می‌کند.

## امکانات نسخه ۱

- وارد کردن کانفیگ‌های `.conf` از فایل، یا چسباندن متن کانفیگ
- روشن/خاموش کردن تونل با سوییچ
- نمایش آدرس، اندپوینت و حجم دریافت/ارسال (↓ ↑) هنگام اتصال
- مشاهده‌ی کانفیگ (کلیدهای خصوصی مخفی نمایش داده می‌شوند) و حذف تونل
- رابط فارسی و انگلیسی (طبق زبان گوشی)

## ساخت APK

### روش ۱: Android Studio

1. پوشه‌ی `ARGuard` را در Android Studio باز کن و صبر کن Gradle Sync تمام شود.
2. از منوی `Build > Build Bundle(s) / APK(s) > Build APK(s)` بزن.
3. فایل خروجی: `app/build/outputs/apk/debug/app-debug.apk`

### روش ۲: بدون نصب چیزی (GitHub Actions)

1. یک ریپوی جدید در GitHub بساز و محتوای این پوشه را در آن آپلود کن.
2. به تب **Actions** برو، workflow با نام **Build APK** را اجرا کن (یا با push خودکار اجرا می‌شود).
3. بعد از چند دقیقه، از بخش **Artifacts** فایل `ARGuard-debug-apk` را دانلود کن.

APK ساخته‌شده «debug» است و مستقیم روی گوشی نصب می‌شود (نصب از منابع ناشناس را فعال کن).
