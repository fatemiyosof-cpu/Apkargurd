package com.arguard.app

import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private var pendingName: String? = null

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val name = pendingName
            pendingName = null
            if (name != null) {
                if (result.resultCode == RESULT_OK) vm.toggle(name)
                else vm.showMessage(getString(R.string.vpn_denied))
            }
        }

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.importUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArGuardTheme {
                ArGuardScreen(
                    vm = vm,
                    onToggle = ::requestToggle,
                    onImportFile = { filePicker.launch(arrayOf("*/*")) },
                )
            }
        }
    }

    private fun requestToggle(name: String, isUp: Boolean) {
        if (!isUp) {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                pendingName = name
                vpnPermission.launch(intent)
                return
            }
        }
        vm.toggle(name)
    }
}
