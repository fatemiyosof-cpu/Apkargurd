package com.arguard.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.File

data class TunnelUi(
    val name: String,
    val isUp: Boolean,
    val busy: Boolean,
    val address: String,
    val endpoint: String,
    val rx: Long,
    val tx: Long,
)

class ArTunnel(private val tunnelName: String, val config: Config) : Tunnel {
    @Volatile
    var state: Tunnel.State = Tunnel.State.DOWN

    override fun getName(): String = tunnelName

    override fun onStateChange(newState: Tunnel.State) {
        state = newState
    }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val backend = (application as ArApp).backend
    private val dir = File(application.filesDir, "tunnels").apply { mkdirs() }
    private val lock = Any()
    private val tunnels = LinkedHashMap<String, ArTunnel>()
    private val busy = mutableSetOf<String>()

    private val _ui = MutableStateFlow<List<TunnelUi>>(emptyList())
    val ui: StateFlow<List<TunnelUi>> = _ui.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            loadSaved()
            publish()
            while (isActive) {
                delay(1000)
                val anyUp = synchronized(lock) { tunnels.values.any { it.state == Tunnel.State.UP } }
                if (anyUp) publish()
            }
        }
    }

    fun showMessage(text: String) {
        _messages.tryEmit(text)
    }

    private fun str(id: Int, vararg args: Any): String = getApplication<Application>().getString(id, *args)

    private fun loadSaved() {
        val running = runCatching { backend.runningTunnelNames }.getOrDefault(emptySet())
        dir.listFiles { f -> f.extension == "conf" }
            ?.sortedBy { it.name }
            ?.forEach { f ->
                try {
                    val cfg = f.inputStream().use { Config.parse(it) }
                    val t = ArTunnel(f.nameWithoutExtension, cfg)
                    if (t.name in running) t.state = Tunnel.State.UP
                    synchronized(lock) { tunnels[t.name] = t }
                } catch (_: Exception) {
                    // skip unreadable files
                }
            }
    }

    private fun publish() {
        val (list, busyNow) = synchronized(lock) { tunnels.values.toList() to busy.toSet() }
        _ui.value = list.map { t ->
            val up = t.state == Tunnel.State.UP
            var rx = 0L
            var tx = 0L
            if (up) {
                runCatching {
                    val s = backend.getStatistics(t)
                    rx = s.totalRx()
                    tx = s.totalTx()
                }
            }
            val cfg = t.config
            TunnelUi(
                name = t.name,
                isUp = up,
                busy = t.name in busyNow,
                address = cfg.getInterface().addresses.joinToString(", "),
                endpoint = cfg.peers.firstNotNullOfOrNull { p -> p.endpoint.orElse(null)?.toString() } ?: "",
                rx = rx,
                tx = tx,
            )
        }
    }

    /** Turns the tunnel on or off. The VPN permission must already be granted when turning on. */
    fun toggle(name: String) {
        val t = synchronized(lock) { tunnels[name] } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            synchronized(lock) { busy += name }
            publish()
            try {
                if (t.state == Tunnel.State.UP) {
                    backend.setState(t, Tunnel.State.DOWN, t.config)
                    t.state = Tunnel.State.DOWN
                } else {
                    val others = synchronized(lock) {
                        tunnels.values.filter { it !== t && it.state == Tunnel.State.UP }
                    }
                    others.forEach {
                        backend.setState(it, Tunnel.State.DOWN, it.config)
                        it.state = Tunnel.State.DOWN
                    }
                    backend.setState(t, Tunnel.State.UP, t.config)
                    t.state = Tunnel.State.UP
                }
            } catch (e: Exception) {
                _messages.tryEmit(describe(e))
            } finally {
                synchronized(lock) { busy -= name }
                publish()
            }
        }
    }

    fun importUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cr = getApplication<Application>().contentResolver
                var display: String? = null
                cr.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) display = c.getString(i)
                }
                val text = cr.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException(str(R.string.read_failed))
                addConfigNow((display ?: "tunnel").removeSuffix(".conf"), text)
            } catch (e: Exception) {
                _messages.tryEmit(describe(e))
            }
        }
    }

    fun addConfig(rawName: String, text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                addConfigNow(rawName, text)
            } catch (e: Exception) {
                _messages.tryEmit(describe(e))
            }
        }
    }

    private fun addConfigNow(rawName: String, text: String) {
        val cfg = Config.parse(ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))
        val name = uniqueName(sanitize(rawName))
        File(dir, "$name.conf").writeText(cfg.toWgQuickString())
        synchronized(lock) { tunnels[name] = ArTunnel(name, cfg) }
        publish()
        _messages.tryEmit(str(R.string.imported, name))
    }

    fun delete(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val t = synchronized(lock) { tunnels[name] } ?: return@launch
            try {
                if (t.state == Tunnel.State.UP) {
                    backend.setState(t, Tunnel.State.DOWN, t.config)
                    t.state = Tunnel.State.DOWN
                }
            } catch (_: Exception) {
            }
            File(dir, "$name.conf").delete()
            synchronized(lock) { tunnels.remove(name) }
            publish()
        }
    }

    /** Config text for display, with secret keys masked. */
    fun preview(name: String): String {
        val t = synchronized(lock) { tunnels[name] } ?: return ""
        return t.config.toWgQuickString()
            .replace(Regex("(?m)^(PrivateKey|PresharedKey)\\s*=.*$"), "\$1 = ••••••••")
    }

    private fun sanitize(n: String): String {
        val s = n.trim().replace(Regex("[^a-zA-Z0-9_=+.-]"), "_").trim('_').take(15)
        return s.ifEmpty { "tunnel" }
    }

    private fun uniqueName(base: String): String {
        val taken = synchronized(lock) { tunnels.keys.toSet() }
        if (base !in taken) return base
        var i = 2
        var cand: String
        do {
            val suffix = "-$i"
            cand = base.take(15 - suffix.length) + suffix
            i++
        } while (cand in taken)
        return cand
    }

    private fun describe(e: Exception): String = when (e) {
        is BadConfigException -> str(R.string.bad_config, "${e.section} / ${e.location}: ${e.reason}")
        else -> e.message ?: e.javaClass.simpleName
    }
}
