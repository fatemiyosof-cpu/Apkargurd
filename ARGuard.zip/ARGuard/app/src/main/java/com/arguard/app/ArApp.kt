package com.arguard.app

import android.app.Application
import com.wireguard.android.backend.GoBackend

class ArApp : Application() {
    lateinit var backend: GoBackend
        private set

    override fun onCreate() {
        super.onCreate()
        backend = GoBackend(applicationContext)
    }
}
