package com.arguard.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF05210F),
    primaryContainer = Color(0xFF14532D),
    onPrimaryContainer = Color(0xFFD1FAE5),
    secondary = Color(0xFF86EFAC),
    background = Color(0xFF0E1511),
    onBackground = Color(0xFFE6EEE8),
    surface = Color(0xFF16201A),
    onSurface = Color(0xFFE6EEE8),
    surfaceVariant = Color(0xFF1E2B23),
    onSurfaceVariant = Color(0xFFA8B8AE),
    error = Color(0xFFF87171),
)

@Composable
fun ArGuardTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
