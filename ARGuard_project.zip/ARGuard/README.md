# AR Guard

Android VPN app (WireGuard-based) with Compose UI.

## ساخت APK (بدون Android Studio)
1. یک ریپوی خصوصی در GitHub بساز و کل این پوشه را push کن.
2. تب Actions → "Build APK" → بعد از اتمام، فایل AR-Guard-apk را دانلود کن.

## ساخت با Android Studio
پوشه را باز کن، Sync کن، Build > Build APK(s).

## قابلیت‌ها
- ایمپورت .conf (چند فایل همزمان) و ZIP (چند کانفیگ داخل یک زیپ، حتی زیپ تو در تو)
- Paste: متن WireGuard یا لینک‌های vless/vmess/trojan/ss (چند خط)
- لینک ساب (http/https، محتوای base64 یا متن ساده، حتی ZIP)
- ادیت کامل هر کانفیگ: فرم (Private key, Address, DNS + دکمه‌های Cloudflare/Google/Quad9, MTU, Public key, Preshared, Endpoint, AllowedIPs, Keepalive) یا متن خام

## محدودیت
اتصال WireGuard با هسته رسمی wireguard-go انجام می‌شود. vless/vmess/trojan/ss فعلاً ذخیره، نمایش و ادیت می‌شوند اما برای اتصال به هسته Xray (مثلاً libXray AAR) نیاز دارند که باید به پروژه اضافه شود.
