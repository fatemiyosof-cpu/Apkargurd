package com.arguard.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

class WgTunnel(private val n: String) : Tunnel {
    override fun getName() = n
    override fun onStateChange(newState: Tunnel.State) {}
}

class VM(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    val profiles = mutableStateListOf<Profile>()
    var selected by mutableStateOf<String?>(null)
    var state by mutableIntStateOf(0) // 0 off, 1 connecting, 2 on
    var msg by mutableStateOf<String?>(null)
    var rx by mutableLongStateOf(0L)
    var tx by mutableLongStateOf(0L)
    private val backend = GoBackend(ctx)
    private var tun: WgTunnel? = null

    init {
        profiles.addAll(Store.load(ctx))
        selected = profiles.firstOrNull()?.id
    }

    val current: Profile? get() = profiles.firstOrNull { it.id == selected }
    private fun persist() = Store.save(ctx, profiles)

    private fun add(r: ImportResult) {
        profiles.addAll(r.items)
        if (selected == null) selected = profiles.firstOrNull()?.id
        persist()
        msg = if (r.items.isEmpty()) "Nothing imported" + (r.error?.let { ": $it" } ?: "")
        else "Imported ${r.items.size} config(s)" + if (r.failed > 0) ", ${r.failed} failed" else ""
    }

    private fun displayName(u: Uri): String {
        ctx.contentResolver.query(u, null, null, null, null)?.use {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && it.moveToFirst()) return it.getString(i).substringBeforeLast('.')
        }
        return "Imported"
    }

    fun importUris(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            var all = ImportResult(emptyList(), 0, null)
            for (u in uris) {
                all += try {
                    val bytes = ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
                    Importer.fromBytes(bytes, displayName(u))
                } catch (e: Exception) { ImportResult(emptyList(), 1, e.message) }
            }
            withContext(Dispatchers.Main) { add(all) }
        }
    }

    fun importText(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val t = text.trim()
            val r = try {
                if (Regex("^https?://\\S+$", RegexOption.IGNORE_CASE).matches(t)) Importer.fromUrl(t)
                else Importer.fromText(t, "Pasted")
            } catch (e: Exception) { ImportResult(emptyList(), 1, e.message) }
            withContext(Dispatchers.Main) { add(r) }
        }
    }

    fun importSub(url: String) = importText(url.trim())

    fun update(p: Profile) {
        val i = profiles.indexOfFirst { it.id == p.id }
        if (i >= 0) { profiles[i] = p; persist() }
    }

    fun delete(id: String) {
        if (id == selected && state != 0) disconnect()
        profiles.removeAll { it.id == id }
        if (selected == id) selected = profiles.firstOrNull()?.id
        persist()
    }

    fun connect() {
        val p = current ?: return
        if (p.kind != "wg") {
            msg = "${p.kind.uppercase()} links need the Xray core (see README). WireGuard configs work now."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            state = 1
            try {
                val cfg = Config.parse(BufferedReader(StringReader(p.text)))
                val t = WgTunnel("arguard")
                backend.setState(t, Tunnel.State.UP, cfg)
                tun = t
                state = 2
                while (state == 2) {
                    try {
                        val s = backend.getStatistics(t)
                        rx = s.totalRx(); tx = s.totalTx()
                    } catch (_: Exception) {}
                    delay(1000)
                }
            } catch (e: Exception) {
                msg = e.message ?: "Connection failed"
                state = 0
            }
        }
    }

    fun disconnect() {
        val t = tun ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try { backend.setState(t, Tunnel.State.DOWN, null) } catch (e: Exception) { msg = e.message }
            state = 0; rx = 0; tx = 0; tun = null
        }
    }
}
