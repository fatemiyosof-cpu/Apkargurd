package com.arguard.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader
import kotlin.random.Random

val BG = Color(0xFF0A0A0E)
val CARD = Color(0xFF14141B)
val GREEN = Color(0xFF14B35C)
val RED = Color(0xFFE11D2E)
val GOLD = Color(0xFFD4AF37)

@Composable
fun Bg() {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 1f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "t"
    )
    val pts = remember { List(40) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), 0.3f + Random.nextFloat() * 0.7f) } }
    Canvas(Modifier.fillMaxSize()) {
        drawRect(BG)
        drawRect(Brush.radialGradient(listOf(GREEN.copy(alpha = .30f), Color.Transparent), Offset(0f, 0f), size.width * 1.1f))
        drawRect(Brush.radialGradient(listOf(RED.copy(alpha = .30f), Color.Transparent), Offset(size.width, size.height), size.width * 1.1f))
        pts.forEach {
            val y = ((it[1] - t * it[2]) % 1f + 1f) % 1f
            drawCircle(GOLD.copy(alpha = .28f * it[2]), 1.5.dp.toPx() * it[2] + 1f, Offset(it[0] * size.width, y * size.height))
        }
    }
}

@Composable
fun PowerButton(state: Int, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pb")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(if (state == 1) 900 else 7000, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val main by animateColorAsState(when (state) { 2 -> GREEN; 1 -> GOLD; else -> RED }, tween(500), label = "col")
    Box(
        Modifier.size(230.dp).clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center; val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(main.copy(alpha = .38f), Color.Transparent), c, r), r * pulse)
            rotate(spin) {
                drawCircle(
                    Brush.sweepGradient(colors = listOf(main, Color.Transparent, GOLD, Color.Transparent, main), center = c),
                    r * 0.82f, style = Stroke(8.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            drawCircle(Color(0xFF111118), r * 0.62f)
            drawCircle(main, r * 0.62f, style = Stroke(3.dp.toPx()))
            val ir = r * 0.26f
            drawArc(main, -60f, 300f, false, Offset(c.x - ir, c.y - ir), Size(ir * 2, ir * 2), style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
            drawLine(main, Offset(c.x, c.y - ir * 1.25f), Offset(c.x, c.y - ir * 0.1f), 7.dp.toPx(), StrokeCap.Round)
        }
    }
}

fun fmt(b: Long): String = when {
    b > 1 shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b > 1 shl 20 -> "%.1f MB".format(b / 1048576.0)
    b > 1024 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}

@Composable
fun ARGuardApp(vm: VM, onToggle: () -> Unit, onPickFiles: () -> Unit) {
    var editing by remember { mutableStateOf<Profile?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = GREEN, secondary = GOLD, background = BG, surface = CARD)) {
        Box(Modifier.fillMaxSize()) {
            Bg()
            val e = editing
            if (e != null) {
                EditScreen(e, onBack = { editing = null }, onSave = { vm.update(it); editing = null })
            } else {
                Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp)) {
                    Header()
                    val st = vm.state
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        PowerButton(st, onToggle)
                        Text(
                            when (st) { 2 -> "PROTECTED"; 1 -> "CONNECTING..."; else -> "TAP TO CONNECT" },
                            color = when (st) { 2 -> GREEN; 1 -> GOLD; else -> Color.White.copy(alpha = .7f) },
                            fontWeight = FontWeight.Bold, letterSpacing = 3.sp, fontSize = 14.sp
                        )
                        Text(vm.current?.name ?: "No config selected", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 6.dp))
                        AnimatedVisibility(st == 2, enter = fadeIn() + slideInVertically()) {
                            Text("↓ ${fmt(vm.rx)}     ↑ ${fmt(vm.tx)}", color = GOLD, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(vm.profiles, key = { it.id }) { p ->
                            val vis = remember { MutableTransitionState(false).apply { targetState = true } }
                            AnimatedVisibility(vis, enter = fadeIn() + slideInVertically { it / 3 }) {
                                ProfileCard(p, p.id == vm.selected, { if (vm.state == 0) vm.selected = p.id },
                                    { editing = p }, { vm.delete(p.id) })
                            }
                        }
                        if (vm.profiles.isEmpty()) item {
                            Text("No configs yet.\nTap + to import a .conf, a ZIP, paste vless/vmess/WireGuard text or add a subscription link.",
                                color = Color.White.copy(alpha = .6f), modifier = Modifier.padding(24.dp))
                        }
                    }
                }
                Box(Modifier.align(Alignment.BottomEnd).systemBarsPadding().padding(20.dp)) {
                    FloatingActionButton(onClick = { menu = true }, containerColor = GREEN, contentColor = Color.White, shape = CircleShape) {
                        Icon(Icons.Default.Add, null)
                    }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Import file (.conf / .zip)") }, { menu = false; onPickFiles() })
                        DropdownMenuItem({ Text("Paste config / links") }, { menu = false; dialog = "paste" })
                        DropdownMenuItem({ Text("Subscription link") }, { menu = false; dialog = "sub" })
                    }
                }
                if (dialog == "paste") TextDialog("Paste config", "WireGuard [Interface] text, vless:// vmess:// trojan:// ss:// links (one per line)", 8,
                    { dialog = null }) { vm.importText(it); dialog = null }
                if (dialog == "sub") TextDialog("Subscription link", "https://...", 1, { dialog = null }) { vm.importSub(it); dialog = null }
            }
        }
    }
}

@Composable
fun Header() {
    val x by rememberInfiniteTransition(label = "h").animateFloat(0f, 600f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "x")
    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(46.dp).clip(CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(
            "AR GUARD", fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp,
            style = TextStyle(brush = Brush.linearGradient(listOf(GREEN, Color.White, RED, GOLD, GREEN), Offset(x - 300, 0f), Offset(x + 300, 0f), androidx.compose.ui.graphics.TileMode.Mirror))
        )
    }
}

@Composable
fun ProfileCard(p: Profile, sel: Boolean, onSelect: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val border by animateColorAsState(if (sel) GOLD else Color.White.copy(alpha = .08f), label = "b")
    val badge = if (p.kind == "wg") GREEN else RED
    val sub = if (p.kind == "wg") Ini.get(p.text, "Peer", "Endpoint") else p.text.substringAfter("@", "").substringBefore("?").substringBefore("#")
    Card(
        Modifier.fillMaxWidth().clickable { onSelect() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CARD.copy(alpha = .92f)),
        border = BorderStroke(if (sel) 1.5.dp else 1.dp, border)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(badge.copy(alpha = .2f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text(if (p.kind == "wg") "WG" else p.kind.uppercase(), color = badge, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (sub.isNotBlank()) Text(sub, color = Color.White.copy(alpha = .5f), fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onEdit) { Icon(Icons.Default.Edit, "Edit", tint = GOLD) }
            IconButton(onDelete) { Icon(Icons.Default.Delete, "Delete", tint = RED) }
        }
    }
}

@Composable
fun TextDialog(title: String, hint: String, lines: Int, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, placeholder = { Text(hint, fontSize = 12.sp) }, minLines = lines, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ if (t.isNotBlank()) onOk(t) }) { Text("Import") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun EditScreen(p: Profile, onBack: () -> Unit, onSave: (Profile) -> Unit) {
    var name by remember { mutableStateOf(p.name) }
    var text by remember { mutableStateOf(p.text) }
    var raw by remember { mutableStateOf(p.kind != "wg") }
    var err by remember { mutableStateOf<String?>(null) }

    @Composable
    fun F(label: String, section: String, key: String) {
        OutlinedTextField(Ini.get(text, section, key), { text = Ini.set(text, section, key, it) },
            label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp))
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("Edit config", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button({
                if (p.kind == "wg") {
                    try { Config.parse(BufferedReader(StringReader(text))); onSave(p.copy(name = name.ifBlank { p.name }, text = text)) }
                    catch (e: Exception) { err = e.message }
                } else onSave(p.copy(name = name.ifBlank { p.name }, text = text.trim()))
            }, colors = ButtonDefaults.buttonColors(containerColor = GREEN)) { Text("Save") }
        }
        err?.let { Text(it, color = RED, modifier = Modifier.padding(vertical = 6.dp)) }
        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        if (p.kind == "wg") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!raw, { raw = false }, { Text("Form") })
                FilterChip(raw, { raw = true }, { Text("Raw text") })
            }
        }
        if (raw) {
            OutlinedTextField(text, { text = it }, minLines = 12, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                label = { Text(if (p.kind == "wg") ".conf" else "Link") })
        } else {
            SectionTitle("Interface")
            F("Private key", "Interface", "PrivateKey")
            F("Address", "Interface", "Address")
            F("DNS", "Interface", "DNS")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip({ text = Ini.set(text, "Interface", "DNS", "1.1.1.1, 1.0.0.1") }, { Text("Cloudflare") })
                AssistChip({ text = Ini.set(text, "Interface", "DNS", "8.8.8.8, 8.8.4.4") }, { Text("Google") })
                AssistChip({ text = Ini.set(text, "Interface", "DNS", "9.9.9.9") }, { Text("Quad9") })
            }
            F("MTU", "Interface", "MTU")
            F("Listen port", "Interface", "ListenPort")
            SectionTitle("Peer")
            F("Public key", "Peer", "PublicKey")
            F("Preshared key", "Peer", "PresharedKey")
            F("Endpoint", "Peer", "Endpoint")
            F("Allowed IPs", "Peer", "AllowedIPs")
            F("Persistent keepalive", "Peer", "PersistentKeepalive")
        }
    }
}

@Composable
fun SectionTitle(s: String) = Text(s.uppercase(), color = GOLD, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
    modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
