package com.arguard.app

import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.wireguard.android.backend.GoBackend

class MainActivity : ComponentActivity() {
    private val vm: VM by viewModels()

    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) vm.connect() else vm.msg = "VPN permission denied"
    }
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) vm.importUris(it)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LaunchedEffect(vm.msg) {
                vm.msg?.let { Toast.makeText(this@MainActivity, it, Toast.LENGTH_LONG).show(); vm.msg = null }
            }
            ARGuardApp(
                vm = vm,
                onToggle = {
                    if (vm.state == 2) vm.disconnect()
                    else if (vm.state == 0 && vm.current != null) {
                        val i = GoBackend.VpnService.prepare(this)
                        if (i != null) vpnPerm.launch(i) else vm.connect()
                    } else if (vm.current == null) vm.msg = "Import a config first"
                },
                onPickFiles = { picker.launch(arrayOf("*/*")) }
            )
        }
    }
}
