package com.arguard.app

import android.content.Context
import android.util.Base64
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.UUID
import java.util.zip.ZipInputStream

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String,   // "wg", "vless", "vmess", "trojan", "ss", ...
    val text: String    // .conf content or the raw share link
)

data class ImportResult(val items: List<Profile>, val failed: Int, val error: String?) {
    operator fun plus(o: ImportResult) = ImportResult(items + o.items, failed + o.failed, error ?: o.error)
}

object Store {
    private fun file(c: Context) = File(c.filesDir, "profiles.json")
    fun load(c: Context): List<Profile> = try {
        val a = JSONArray(file(c).readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Profile(o.getString("id"), o.getString("name"), o.getString("kind"), o.getString("text"))
        }
    } catch (e: Exception) { emptyList() }

    fun save(c: Context, l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("kind", it.kind).put("text", it.text)) }
        file(c).writeText(a.toString())
    }
}

class Section(val name: String, val map: LinkedHashMap<String, String> = LinkedHashMap())

object Ini {
    private val multi = setOf("address", "dns", "allowedips")

    fun parse(t: String): MutableList<Section> {
        val out = mutableListOf<Section>()
        var cur: Section? = null
        for (raw in t.lines()) {
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith("#")) continue
            if (l.startsWith("[") && l.endsWith("]")) {
                cur = Section(l.substring(1, l.length - 1)); out.add(cur)
            } else {
                val i = l.indexOf('=')
                if (i > 0 && cur != null) {
                    val k = l.substring(0, i).trim(); val v = l.substring(i + 1).trim()
                    val old = cur.map[k]
                    cur.map[k] = if (old != null && k.lowercase() in multi) "$old, $v" else v
                }
            }
        }
        return out
    }

    fun build(s: List<Section>) = s.joinToString("\n\n") { sec ->
        "[" + sec.name + "]\n" + sec.map.entries.joinToString("\n") { "${it.key} = ${it.value}" }
    } + "\n"

    fun get(text: String, section: String, key: String): String {
        val s = parse(text).firstOrNull { it.name.equals(section, true) } ?: return ""
        return s.map.entries.firstOrNull { it.key.equals(key, true) }?.value ?: ""
    }

    fun set(text: String, section: String, key: String, value: String): String {
        val l = parse(text)
        var s = l.firstOrNull { it.name.equals(section, true) }
        if (s == null) {
            if (value.isBlank()) return text
            s = Section(section)
            if (section.equals("Interface", true)) l.add(0, s) else l.add(s)
        }
        val existing = s.map.keys.firstOrNull { it.equals(key, true) }
        if (value.isBlank()) { if (existing != null) s.map.remove(existing) } else s.map[existing ?: key] = value
        return build(l)
    }
}

object Importer {
    private val schemes = listOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "tuic")
    private val linkRe = Regex("^(${schemes.joinToString("|")})://\\S+", RegexOption.IGNORE_CASE)

    private fun b64(s: String): String? = try {
        var x = s.trim().replace('-', '+').replace('_', '/')
        while (x.length % 4 != 0) x += "="
        String(Base64.decode(x, Base64.DEFAULT))
    } catch (e: Exception) { null }

    fun linkName(l: String): String {
        try {
            if (l.startsWith("vmess://", true)) {
                val j = JSONObject(b64(l.substring(8)) ?: "{}")
                val ps = j.optString("ps")
                if (ps.isNotEmpty()) return ps
                return "VMESS " + j.optString("add")
            }
            val frag = l.substringAfter('#', "")
            if (frag.isNotEmpty()) return URLDecoder.decode(frag, "UTF-8")
            val host = l.substringAfter("@", l.substringAfter("://")).substringBefore("?").substringBefore("#")
            return l.substringBefore("://").uppercase() + " " + host
        } catch (e: Exception) { return l.substringBefore("://").uppercase() }
    }

    fun fromText(text: String, hint: String, depth: Int = 0): ImportResult {
        val t = text.replace("\r", "").trim()
        val res = mutableListOf<Profile>()
        var failed = 0
        var error: String? = null
        if (t.contains("[Interface]", true)) {
            val blocks = Regex("(?im)(?=^\\s*\\[Interface\\])").split(t).filter { it.isNotBlank() }
            blocks.forEachIndexed { i, b ->
                try {
                    Config.parse(BufferedReader(StringReader(b)))
                    res.add(Profile(name = if (blocks.size > 1) "$hint ${i + 1}" else hint, kind = "wg", text = b.trim() + "\n"))
                } catch (e: Exception) { failed++; if (error == null) error = e.message }
            }
        } else {
            t.lines().map { it.trim() }.filter { linkRe.matches(it) }.forEach {
                res.add(Profile(name = linkName(it), kind = it.substringBefore("://").lowercase(), text = it))
            }
        }
        if (res.isEmpty() && failed == 0 && depth == 0) {
            val d = b64(t)
            if (d != null && (d.contains("://") || d.contains("[Interface]", true))) return fromText(d, hint, 1)
        }
        return ImportResult(res, failed, error)
    }

    fun fromZip(s: InputStream, depth: Int = 0): ImportResult {
        var all = ImportResult(emptyList(), 0, null)
        ZipInputStream(s).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory || e.name.contains("__MACOSX")) continue
                val bytes = z.readBytes()
                if (bytes.size > 3_000_000) continue
                val name = File(e.name).nameWithoutExtension
                all += fromBytes(bytes, name, depth + 1)
            }
        }
        return all
    }

    fun fromBytes(b: ByteArray, name: String, depth: Int = 0): ImportResult {
        if (depth > 3) return ImportResult(emptyList(), 0, null)
        return if (b.size > 1 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte())
            fromZip(ByteArrayInputStream(b), depth)
        else fromText(String(b), name.ifBlank { "Imported" })
    }

    suspend fun fromUrl(u: String): ImportResult = withContext(Dispatchers.IO) {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "AR-Guard/1.0")
        val b = c.inputStream.use { it.readBytes() }
        fromBytes(b, "Sub")
    }
}
